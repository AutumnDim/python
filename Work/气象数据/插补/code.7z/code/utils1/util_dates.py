# -*- coding: utf-8 -*-
"""
Created on Thu May  9 19:25:32 2024

@author: lc
"""
import pandas as pd
import numpy as np
from datetime import datetime,timedelta

A_WEEK = timedelta(days=7)
TWO_WEEKS = timedelta(days=14)

#计算月份最后一日
def month_day(year,month):
    """
    计算月份最后一日

    参数
    ----------
    year : int
        所需计算数据的年份信息
    month : int
        所需计算数据的月份信息

    返回值
    -------
    int
        月份最后一日

    """
    if month in [1,3,5,7,8,10,12]:
        return 31
    elif month in [4,6,9,11]:
        return 30
    elif month == 2:
        if year%100 ==0:
            if year%400 ==0:
                return 29
            else:
                return 28
        else:
            if year%4==0:
                return 29
            else:
                return 28

#获取以start_time到end_time之间的时间的数组
def get_date_array(start_time,end_time):
    """
    获取以start_time到end_time之间的时间的数组

    参数
    ----------
    start_time : datetime
        起始时间
    end_time : datetime
        终止时间

    返回值
    -------
    numpy.ndarray
        start_time到end_time之间的时间的数组

    """
    tlist = []
    for i in range((end_time-start_time).days+1):
        tlist.append(start_time+timedelta(days=i))
    return np.array(tlist)

#获取某个月的第一天和最后一天
def get_mth_str_end_dates(month,year):
    """
    获取某个月的第一天和最后一天

    参数
    ----------
    month : int
        所需计算的月份数据
    year : int
        所需计算的月份数据所在年份

    返回值
    -------
    start_date : int
        第一天
    end_date : int
        最后一天

    """
    start_date = datetime(year,month,1)
    last_date = month_day(year,month)
    end_date = datetime(year,month,last_date)
    return start_date,end_date

#获取月与日的结合
def get_md_array(dates):
    """
    获取月份与日的结合

    参数
    ----------
    dates : numpy.ndarray
        需计算的时间数据,数组类型为datetime

    返回值
    -------
    numpy.ndarray
        由"月-日"形式构成的数组

    """
    lst = []
    for date in dates:
        m = date.month
        d = date.day
        lst.append(str(m)+'-'+str(d))
    return np.array(lst)
    


































































