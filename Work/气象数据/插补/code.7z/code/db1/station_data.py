# -*- coding: utf-8 -*-
"""
Created on Sat May 25 10:39:23 2024

@author: 33501
"""
import pandas as pd
from datetime import datetime
import numpy as np
from tqdm import tqdm



LON = u'经度'
LAT = u'纬度'
STN_ID = u'台站'
YEAR = u'年'
MONTH =  u'月'
DAY = u'日'
PRCP = u'降水量'
TMIN = u'日最低气温'
TMAX = u'日最高气温'
YMD = u'年月日'
DATE = u'日期'
YDAY = u'年日'
PRCP_FLAG = u'降水量标记'
TMIN_FLAG = u'日最低气温标记'
TMAX_FLAG = u'日最高气温标记'
TAVG_FLAG = u'日最高气温标记'
TAVG = u'平均气温'


def yd(year,month,day):
    """
    计算某天在该年中处于第几天

    参数
    ----------
    year : int
        年
    month : int
        月
    day : int
        日

    返回值
    -------
    int
        在该年所处天数

    """
    if month==1:
        return day
    if month==2:
        return day+31
    l = 0
    for m in [1,3,5,7,8,10,12]:
        if month <= m:
            break
        l+=1
    if (year%4==0 and year%100!=0) or (year%400==0 and year%100==0):
        return l*31+(month-l-2)*30+29+day
    else:
        return l*31+(month-l-2)*30+28+day


def find_many(arr1):
    """
    这个忘记有没有用了
    """
    lst=[]
    count=[]
    ind=0
    for i in arr1:
        if i in lst:
            count.append(ind)
        lst.append(i)
        print(ind)
        ind+=1
    return count

class station_data: ############
    def     __init__(self,CURS,srtDate=datetime(2015,1,1),endDate=datetime(2015,12,31)):
        """
        创建一个类处理气象站数据的__init__函数
        
        参数
        ----------
        - CURS : Cursor
            台站数据库的游标数据或者处理好的类列表数据
        - srtDate : datetime
            需要处理数据的起始时间,默认值为datetime(2015,1,1)
        - endDate : datetime
            需要处理数据的结束时间,默认值为datetime(2015,12,31)
        """
        self.lis = []
        srty,srtm,srtd = srtDate.year,srtDate.month,srtDate.day
        endy,endm,endd = endDate.year,endDate.month,endDate.day
        years = [i for i in range(srty,endy+1)]
        time = list(pd.date_range(srtDate,endDate))
        if type(CURS) is not list:
            df = []
            for year in years:
                # df+=(list(CURS.execute(f"SELECT 台站,纬度,经度,年,月,日,降水量,平均气温 FROM all{year}")))
                df += (list(CURS.execute(f"SELECT 台站,纬度,经度,年,月,日,日最低气温,日最高气温 FROM all{year}")))
                # df += (list(CURS.execute(f"SELECT 台站,纬度,经度,年,月,日,日最低气温,日最高气温,降水量,平均气温 FROM all{year}")))
                # # 新
                # df += (list(CURS.execute(f"SELECT 台站,纬度,经度,年,月,日,日最低气温,日最高气温")))
            d_list = list(set([tuple(i)+(datetime(i[3],i[4],i[5]),) for i in df]))
        else:
            d_list=CURS
        # 新
        self.data = np.array(d_list,dtype=[(STN_ID,'U11'),(LAT,np.float16),(LON,np.float16),(YEAR,np.uint16),(MONTH,np.uint8),(DAY,np.uint8),(TMIN,np.float16),(TMAX,np.float16),(DATE,datetime)])
        # self.data = np.array(d_list,dtype=[(STN_ID,'U11'),(LAT,np.float16),(LON,np.float16),(YEAR,np.uint16),(MONTH,np.uint8),(DAY,np.uint8),(PRCP,np.float16),(TAVG,np.float16),(DATE,datetime)])
        # self.data = np.array(d_list,dtype=[(STN_ID,'U11'),(LAT,float),(LON,float),(YEAR,int),(MONTH,int),(DAY,int),(TMIN,float),(TMAX,float),(DATE,datetime)])
        # self.data = np.array(d_list,dtype=[(STN_ID,'U11'),(LAT,float),(LON,float),(YEAR,int),(MONTH,int),(DAY,int),(TMIN,float),(TMAX,float),(PRCP,float),(TAVG,float),(DATE,datetime)])
        if (srtm!=1 and srtd!=1) or (endm!=12 and endd!=31):
            self.data = self.data[self.data[DATE]>=srtDate]
            self.data = self.data[self.data[DATE]<=endDate]
        self.data[TMIN][self.data[TMIN]==999990.0] = np.nan
        self.data[TMAX][self.data[TMAX]==999990.0] = np.nan
        self.data[TMIN][self.data[TMIN]==999999.0] = np.nan
        self.data[TMAX][self.data[TMAX]==999999.0] = np.nan
        
        # self.data[PRCP][self.data[PRCP]==999999.0] = np.nan
        # self.data[TAVG][self.data[TAVG] == 999999.0] = np.nan
        # self.data[PRCP][self.data[PRCP]==999990.0] = np.nan
        # self.data[TAVG][self.data[TAVG] == 999990.0] = np.nan
        station = set(self.data[STN_ID])
        data_use = self.data
        counter=1
        new_records = []

        for s in tqdm(station, desc="Processing stations", unit="station"):
            counter += 1
            d = data_use[data_use[STN_ID] == s]

            # 如果该站点在所有时间上都有数据，跳过
            if len(d) == len(time):
                continue

            # 找到该站点缺失的时间点
            dt = set(d[DATE])
            nan_dates = set(time) - dt
            # print(f"调试信息：缺失日期数: {len(nan_dates)}, 示例日期: {list(nan_dates)[:5]}")

            # 生成缺失数据的记录并添加到列表
            new_records.extend([
                (s, d[LAT][0], d[LON][0], t.year, t.month, t.day, np.nan, np.nan, t)
                for t in nan_dates
            ])

        # 如果有新数据要添加
        if new_records:
            # 将新数据转化为结构化数组
            # 新
            new_data_array = np.array(
                new_records,
                dtype=[(STN_ID, 'U5'), (LAT, np.float16), (LON, np.float16),
                       (YEAR, np.uint16), (MONTH, np.uint8), (DAY, np.uint8),
                       (TMIN, np.float16), (TMAX, np.float16), (DATE, datetime)]
            )
            # 原
            # new_data_array = np.array(
            #     new_records,
            #     dtype=[(STN_ID, 'U5'), (LAT, np.float16), (LON, np.float16),
            #            (YEAR, np.uint16), (MONTH, np.uint8), (DAY, np.uint8),
            #            (PRCP, np.float16), (TAVG, np.float16), (DATE, datetime)]
            # )

            # 使用 np.concatenate 一次性拼接数据
            # print(f"调试信息：在合并之前，data_use大小: {data_use.shape}")
            # print(f"调试信息：新数据记录大小: {len(new_records)}")
            data_use = np.concatenate((data_use, new_data_array))
        
        # for s in station:
        #     counter+=1
        #     d = data_use[data_use[STN_ID]==s]
        #     if len(d)==len(time):
        #         continue
        #     dt = list(d[DATE])
        #     nan_date=list(set(time)-set(dt))
        #     data_use = np.r_[data_use,np.array([(s,d[LAT][0],d[LON][0],t.year,t.month,t.day,np.nan,np.nan,t) for t in nan_date],
        #                                        dtype=[(STN_ID,'U5'),(LAT,np.float16),(LON,np.float16),(YEAR,np.uint16)
        #                                              ,(MONTH,np.uint8),(DAY,np.uint8),(PRCP,np.float16),(TAVG,np.float16),
        #                                               (DATE,datetime)])]     #如果一个站点在某个时间序列上没有值，对其进行赋值
            # data_use = np.r_[data_use,np.array([(s,d[LAT][0],d[LON][0],t.year,t.month,t.day,np.nan,np.nan,t) for t in nan_date],dtype=[(STN_ID,'U5'),(LAT,float),(LON,float),(YEAR,int),(MONTH,int),(DAY,int),(TMIN,float),(TMAX,float),(DATE,datetime)])]
            # data_use = np.r_[data_use,np.array([(s,d[LAT][0],d[LON][0],t.year,t.month,t.day,np.nan,np.nan,np.nan,np.nan,t) for t in nan_date],dtype=[(STN_ID,'U5'),(LAT,float),(LON,float),(YEAR,int),(MONTH,int),(DAY,int),(TMIN,float),(TMAX,float),(PRCP,float),(TAVG,float),(DATE,datetime)])]
        # print(f"调试信息：数据大小更新为 {data_use.shape}")
        self.data=data_use
        self.days = []
        self.days.append(pd.date_range(datetime(min(self.data[YEAR]),min(self.data[MONTH]),min(self.data[DAY])),datetime(max(self.data[YEAR]),max(self.data[MONTH]),max(self.data[DAY]))).to_list())
        self.days.append([i.year for i in self.days[0]])
        self.days.append([i.month for i in self.days[0]])
        self.days.append([i.day for i in self.days[0]])
        self.days.append([f'{i.year}-{i.month}-{i.day}' for i in self.days[0]])
        self.days.append([yd(y,m,d) for y,m,d in zip(self.days[1],self.days[2],self.days[3])])
        self.days = np.array(self.days).T
        self.days1 = (self.days)[:,4]
        self.days = np.array([tuple(self.days[i]) for i in range(self.days.shape[0])],dtype=[(DATE,datetime),(YEAR,np.uint16),(MONTH,np.uint8),(DAY,np.uint8),(YMD,'U10'),(YDAY,np.uint16)])
        self.stns = self.data[[STN_ID,LAT,LON]]
        print('okok')
        
    def load_stns(self):
        """
        获取类的stns属性(台站,纬度,经度)
        
        返回值
        -------
        numpy.ndarray
            包含台站(str),纬度(float),经度(float)的数组
        """
        return self.stns
        
    def load_all_stn_obs(self,stid_arr,set_flagged_nan=False):
        """
        获取台站的气温降水数据

        参数
        ----------
        - stid_arr : Array of str160
            所需获取数据的台站
        - set_flagged_nan : bool
            是否获取无效值标记数据,默认值为False.
            - True : 获取
            - False : 不获取

        返回值
        -------
        numpy.ndarray
            包含TMIN(float),TMAX(float),PRCP(float)(若set_flagged_nan=True,TMIN_FLAG(str)
            ,TMAX_FLAG(str),PRCP(str))的数组

        """
        # Tdata=self.data[self.data[STN_ID]==stid_arr][[TMIN,TMAX,PRCP,TAVG,DATE]]
        # self.stn_obs = Tdata[np.argsort(Tdata[DATE])][[TMIN, TMAX, PRCP, TAVG]]
        
        Tdata = self.data[self.data[STN_ID]==stid_arr][[TMIN,TMAX,DATE]]
        self.stn_obs = Tdata[np.argsort(Tdata[DATE])][[TMIN, TMAX]]
        
        # Tdata = self.data[np.isin(self.data[STN_ID], stid_arr)][[PRCP, TAVG, DATE]]
        # self.stn_obs = Tdata[np.argsort(Tdata[DATE])][[PRCP, TAVG]]
        # # 新
        # Tdata = self.data[np.isin(self.data[STN_ID], stid_arr)][[TMIN,TMAX,DATE]]
        # self.stn_obs = Tdata[np.argsort(Tdata[DATE])][[TMIN, TMAX]]
        if set_flagged_nan:
            tf = np.isnan(self.stn_obs)
            self.stn_obs[[TMIN_FLAG,TMAX_FLAG,PRCP_FLAG,TAVG_FLAG]]=[['S' for i in range(self.stn_obs.shape[1])] for i in range(3)]
            self.stn_obs[TMIN_FLAG][tf[TMIN]] = 'I'
            self.stn_obs[TMAX_FLAG][tf[TMAX]] = 'I'
            # self.stn_obs[PRCP_FLAG][tf[PRCP]] = 'I'
            # self.stn_obs[TAVG_FLAG][tf[TAVG]] = 'I'
        return self.stn_obs



















