# -*- coding: utf-8 -*-
"""
Created on Tue May 28 21:07:46 2024

@author: 33501
"""
import numpy as np


#获取大圆距离(两地最短球面距离)
def grt_circle_dist(lon1, lat1, lon2, lat2):
    """
    获取大圆距离(两地最短球面距离)

    参数
    ----------
    lon1 : float
        起始点的经度
    lat1 : float
        起始点的纬度
    lon2 : array_like
        终点的经度数组
    lat2 : array_like
        终点的纬度数组

    返回值
    -------
    distance : numpy.ndarray
        起点与每个终点之间的大圆距离

    """
    lon1, lat1, lon2, lat2 = map(np.radians, [lon1, lat1, lon2, lat2])
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    lat1, lat2, dlat, dlon = map(np.float16, [lat1, lat2, dlat, dlon])
    a = np.sin(dlat / 2.0)**2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2.0)**2
    c = 2 * np.arctan2(np.sqrt(a), np.sqrt(1 - a))
    R = 6371.0          # km
    distance = R * c
    return distance

















