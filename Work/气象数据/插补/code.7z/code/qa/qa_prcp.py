'''
Quality Assurance procedures for prcp daily observations as described in:
Durre, I., M. J. Menne, B. E. Gleason, T. G. Houston, and R. S. Vose. 2010. 
Comprehensive Automated Quality Assurance of Daily Surface Observations. 
Journal of Applied Meteorology and Climatology 49:1615-1633.
'''

import utils.util_dates as utld
import numpy as np
import pandas as pd
from datetime import datetime
import utils.util_geo as utlg
from db.station_data import LON,LAT,STN_ID,PRCP,YEAR,DATE,MONTH,YDAY
from scipy import stats
import math
from scipy.stats import gamma

QA_OK=1
QA_MISSING=2
QA_NAUGHT=3
DUP=25
QA_DUP_YEAR=4
QA_DUP_MONTH=5
QA_DUP_YEAR_MONTH=6
QA_DUP_WITHIN_MONTH=7
QA_IMPOSS_VALUE=8
QA_STREAK=9
QA_GAP=10
QA_INTERNAL_INCONSIST=11
QA_LAGRANGE_INCONSIST=12
QA_SPIKE_DIP=13
QA_MEGA_INCONSIST=14
QA_CLIM_OUTLIER=15
QA_SPATIAL_REGRESS=16
QA_SPATIAL_CORROB=17
QA_MEGA_INCONSIST=18
QA_FREQUENT=19
QA_YR_CLIM_OUTLIER=20
QA_Gamma_distribution=21

PRCP_MIN_VALUE = 0.0
# World Record Daily Prcp (cm)
PRCP_MAX_VALUE = 1828.8                         # mm

#Constants for spatial collaboration checks
MAX_SPATIAL_COLLAB_THRES = 269.24               # 26.924 cm
MAX_SPATIAL_COLLAB_THRES_MM = MAX_SPATIAL_COLLAB_THRES*10.0
NGH_RADIUS = 75.0                               # km
ANOMALY_CUTOFF = 10.0
MIN_DAYS_MTH_WINDOW = 40
MIN_NGHS = 3
MAX_NGHS = 7

STREAK_LEN = 20
GAP_THRES = 300.0                               # mm

MONTHS = np.arange(1,13)
DATES_366 = utld.get_date_array(datetime(1980,1,1),datetime(1980,12,31))
DATES_365 = utld.get_date_array(datetime(2003,1,1),datetime(2003,12,31))
MIN_PERCENTILE_VALUES = 20

#constants for qa_yr_clim_outlier
MIN_YR_DAYS_PRCP_OBS = 245
MIN_NUM_YRS_PRCP = 7
NGH_RESID_CUTOFF = 1000
NGH_RESID_STD_CUTOFF = 0.0

#TODO
def Convert_to_decimal(prcp_qa):
    """
    将降水质量标志（prcp_qa）的多列二进制数据转换为十进制数值。

    参数：
    ----------
    prcp_qa : DataFrame
        包含多个列的降水质量标志数据，每列的数据应是数值格式（整数或浮点数）。
    返回值：
    ----------
    prcp_qa : DataFrame
        包含原始数据及转换后 "质量信息" 和 "十进制" 列的 DataFrame。
    """
    # 将所有数据直接转换为字符串并合并
    prcp_qa = prcp_qa.astype(str)
    # 去掉每个值的小数点及其后的部分
    prcp_qa = prcp_qa.applymap(lambda x: x.split('.')[0])
    # 逐行合并每行的各列数据，形成一个完整的二进制字符串
    prcp_qa["质量信息"] = prcp_qa.agg("".join, axis=1)
    max_len = prcp_qa["质量信息"].str.len().max()
    prcp_qa["质量信息"] = prcp_qa["质量信息"].apply(lambda x: x.zfill(max_len))
    prcp_qa["十进制"] = prcp_qa["质量信息"].apply(lambda x: int(x, 2))

    return prcp_qa

#TODO
def update_flags(df_prcp, flags_prcp, condition, col_name):
    """
     更新降水数据标志位（flags），并将处理后的标志列添加到原数据框中。

     参数：
     ----------
     df_prcp : pandas.DataFrame
         原始降水数据的 DataFrame。
     flags_prcp : array-like
         当前的标志位数组，表示每个降水数据点的状态。
     condition : int or float
         需要更新的标志值条件，例如标记为某一特定值的点。
     col_name : str
         新标志位列的名称。

        返回值：
    ----------
    pandas.DataFrame
        包含新标志位列的降水数据 DataFrame。
    """
    temp_flags = flags_prcp.copy()
    missing_indices = np.where(flags_prcp == condition)     #获取被标记值的索引
    temp_flags[missing_indices] = 0                    #将被标记值赋值为0
    temp_flags = np.array(temp_flags).ravel()
    temp_flags_series = pd.Series(temp_flags, index=df_prcp.index,name=col_name)
    df_prcp = pd.concat([df_prcp, temp_flags_series], axis=1)
    df_prcp[col_name] = df_prcp[col_name].apply(lambda x: float(1) if x not in [0, 1] else x)
    return df_prcp

#TODO
def checks_qa(stn, stn_da,prcp,tavg,days,days1,spatial_prcp):
    prcp[np.isinf(prcp)] = np.nan
    tavg[np.isinf(tavg)] = np.nan
    df_prcp=pd.DataFrame(index=days1)

    flags_prcp = np.ones(prcp.size)
    prcp, flags_prcp = qa_missing(prcp, days, flags_prcp)
    df_prcp = update_flags(df_prcp, flags_prcp, 2, '缺失值')

    # flags_prcp = np.ones(prcp.size)
    prcp, flags_prcp = qa_dup_data(prcp, days, flags_prcp)
    df_prcp = update_flags(df_prcp, flags_prcp, 4, '不同年份之间的重复值')
    df_prcp = update_flags(df_prcp, flags_prcp, 6, '同一年中不同月份的重复值')
    df_prcp = update_flags(df_prcp, flags_prcp, 5, '不同年份之间相同月份的重复值')

    # flags_prcp = np.ones(prcp.size)
    prcp, flags_prcp = qa_imposs_value(prcp, days, flags_prcp)
    df_prcp = update_flags(df_prcp, flags_prcp, 8, '不可能的值')

    prcp,flags_prcp = qa_streak(prcp,days,flags_prcp)
    df_prcp = update_flags(df_prcp, flags_prcp, 9, '20个或以上连续的值')

    prcp,flags_prcp = qa_frequent(prcp,days,flags_prcp)
    df_prcp = update_flags(df_prcp, flags_prcp, 19, '不是必须连续的频繁出现的值')

    # flags_prcp = np.ones(prcp.size)
    prcp, flags_prcp = qa_gap(prcp, days, flags_prcp)
    df_prcp = update_flags(df_prcp, flags_prcp, 10, '频率分布中尾部与其余值异常分离')

    # flags_prcp = np.ones(prcp.size)
    prcp, flags_prcp = qa_clim_outlier(prcp, tavg, days, flags_prcp)
    df_prcp = update_flags(df_prcp, flags_prcp, 15, '20个以下的非零值')

    # flags_prcp = np.ones(prcp.size)
    prcp, flags_prcp = qa_spatial_corrob(stn, stn_da, prcp, days, flags_prcp)
    df_prcp = update_flags(df_prcp, flags_prcp, 17, '未被任何相邻值证实')

    # prcp,flags_prcp = qa_Gamma_distribution(prcp,days)
    # df_prcp = update_flags(df_prcp, flags_prcp, 21, '未通过伽玛分布的置信区间')

    return df_prcp

#TODO
def qa_Gamma_distribution(prcp,days):
    """代码还可以改进，与之前的判断一样用掩码的样式"""
    days1 = days['年日']
    df_prcp = pd.DataFrame(prcp,index=days1)
    times = np.unique(df_prcp.index)
    # 创建一个新数组来存储判断结果
    df_nan = pd.DataFrame(np.nan, index=df_prcp.index, columns=df_prcp.columns)
    #获取多年间相同日期的数据（根据前10年的数据计算参数）
    for time in times:
        value = df_prcp.loc[time]
        value_10 = value[:20]   #筛选出前10年的数据
        data = value_10.replace(0, np.nan).dropna()  # 去除缺失值

        mean_data = data.mean()
        var_data = data.var()

        if len(data) <= 1:                      #这一天连续20年的数据有19天都是0或者nan可不可能呢？
            # 连续20年数据中只有一个大于0的值，设置一个默认参数吧
            shape = 2
            scale = 0.1
            loc = 0
        elif len(data) == 2:
            # 数据值只有两个，用矩估计法拟合
            shape = (mean_data ** 2 / var_data)[0]
            scale = (var_data / mean_data)[0]
            loc = 0
        else:
            # 拟合伽玛分布
            shape, loc, scale = gamma.fit(data, floc=0)

        # 参数验证
        if np.isnan(shape) or shape <= 0:
            print(f"Invalid shape parameter: {shape}. Setting to default value 2.")
            shape = 2
        if np.isnan(scale) or scale <= 0:
            print(f"Invalid scale parameter: {scale}. Setting to default value mean of data.")
            scale = max(mean_data[0], 0.1)  # 确保 scale 大于零
        if np.isnan(loc):
            loc = 0

        # 使用估计的参数定义伽玛分布
        gamma_dist = gamma(a=shape, scale=scale)
        simulated_data = gamma.rvs(shape, loc=loc, scale=scale, size=len(data))    #获取伽玛函数拟合的数据
        # 计算三倍标准差
        mean = np.mean(simulated_data)        #均值
        std_dev = np.std(simulated_data, ddof=1)  # 标准差   ddof=1 表示样本标准差
        lower_bound1 = mean - 3 * std_dev
        upper_bound1 = mean + 3 * std_dev
        # 判断值40年的值是否在置信区间里面
        df_nan.loc[time] = np.where(np.isnan(value), np.nan, np.where((value >= lower_bound1) & (value <= upper_bound1), 1, 21))


        # # 可视化
        # plt.figure(figsize=(10, 6))
        # plt.hist(value, bins=30, edgecolor='k', alpha=0.7, density=True, label='Histogram of Data')
        # # 绘制伽玛分布的PDF
        # x = np.linspace(np.min(value), np.max(value), 4*len(value))
        # pdf = gamma_dist.pdf(x)
        # plt.plot(x, pdf, 'r-', lw=2, label='Fitted Gamma Distribution')
        # # 添加图例和标题
        # plt.title('Histogram of Data and Fitted Gamma Distribution')
        # plt.xlabel('Value')
        # plt.ylabel('Density')
        # plt.legend()
        # # 显示图表
        # plt.show(block=True)

        # # 计算某一天的95%置信区间
        # alpha = 0.95
        # lower_bound, upper_bound = gamma_dist.ppf([0.5 - alpha / 2, 0.5 + alpha / 2])
        # # 判断值40年的值是否在置信区间里面
        # df_nan.loc[time] = np.where((value >= lower_bound) & (value <= upper_bound), 1, 21)
    # df_nan = df_nan.replace(np.nan,21)
    df_nan = df_nan.reset_index(drop=True)
    flags_prcp = df_nan.to_numpy()
    prcp = df_nan.replace(21,np.nan)      #返回处理后的值，便于后面添加条件
    prcp = prcp.to_numpy()
    return prcp,flags_prcp

def run_qa_non_spatial1(prcp,tavg,days):
    '''
    Runs all QA checks in specific order.
    Only includes checks that do not require neighboring station data
    '''
    
    flags_prcp = np.ones(prcp.size)
    
    prcp,flags_prcp = qa_missing(prcp,days,flags_prcp)
    prcp,flags_prcp = qa_dup_data(prcp,days,flags_prcp)
    prcp,flags_prcp = qa_imposs_value(prcp,days,flags_prcp)
    # prcp,flags_prcp = qa_streak(prcp,days,flags_prcp)
    # prcp,flags_prcp = qa_frequent(prcp,days,flags_prcp)
    prcp,flags_prcp = qa_gap(prcp,days,flags_prcp)
    prcp,flags_prcp = qa_clim_outlier(prcp,tavg,days,flags_prcp)
    
    return flags_prcp
    
def run_qa_spatial_only1(stn,stn_da,prcp,tavg,days):
    '''
    Runs all spatial QA checks.
    Only includes checks that do not require neighboring station data
    '''
    
    flags_prcp = np.ones(prcp.size)
    prcp,flags_prcp = qa_missing(prcp,days,flags_prcp)
    prcp,flags_prcp = qa_spatial_corrob(stn, stn_da, prcp, days, flags_prcp)
    #prcp,flags_prcp = qa_yr_clim_outlier(stn,stn_da,prcp,days,flags_prcp)
    
    return flags_prcp

def qa_missing(prcp,days,flags_prcp):
    '''
    Flags all observations that are missing in the specified period of record 
    '''

    mask_miss=np.isnan(prcp)
    
    return update_obs_flags(prcp,flags_prcp,mask_miss,QA_MISSING)

def qa_dup_data(prcp,days,flags_prcp):
    '''
    Runs all duplicate data QA checks
    '''
    
    prcp,flags_prcp = qa_dup_year(prcp,days,flags_prcp)
    prcp,flags_prcp = qa_dup_year_month(prcp,days,flags_prcp)
    prcp,flags_prcp = qa_dup_month(prcp,days,flags_prcp)
    
    return prcp,flags_prcp

def qa_dup_year_month(prcp,days,flags_prcp):
    '''
    Check for duplicate values between different months in the same year
    '''
    
    yrs = np.unique(days[YEAR])
    yr_nums = np.arange(yrs.size)
    mask_prcp = np.zeros(days[DATE].size,dtype=np.bool_)
    
    mths = np.unique(days[MONTH])
    mth_nums = np.arange(mths.size)
    
    for x in yr_nums:
        
        yr_mask = days[YEAR]==yrs[x]
        
        prcp_yr = prcp[yr_mask]
        
        mths_yr = days[MONTH][yr_mask]
        
        for i in mth_nums:
            
            mth1=mths[i]
            mth1_mask = mths_yr==mth1
            
            prcp_yr_mth1 = prcp_yr[mth1_mask]
            
            
            if not (mth1==np.max(mth_nums)) and prcp_yr_mth1[np.logical_and(np.isfinite(prcp_yr_mth1),prcp_yr_mth1>0)].size >= 3:
                
                sub_mths = np.arange(i+1,np.max(mth_nums)+1)
                
                for z in sub_mths:
                    
                    mth2=mths[z]
                    mth2_mask = mths_yr==mth2
                    
                    prcp_yr_mth2 = prcp_yr[mth2_mask]
                    
                    if prcp_yr_mth2[np.logical_and(np.isfinite(prcp_yr_mth2),prcp_yr_mth2>0)].size >= 3 and is_dup_series(prcp_yr_mth1, prcp_yr_mth2):
                        yr_month_mask = np.logical_and(yr_mask,np.logical_or(days[MONTH]==mth1,days[MONTH]==mth2))
                        mask_prcp = np.logical_or(mask_prcp,yr_month_mask)
    
    return update_obs_flags(prcp,flags_prcp,mask_prcp,QA_DUP_YEAR_MONTH)

def qa_dup_year(prcp,days,flags_prcp):

    """
    Check for duplicate values between years
    """
    
    yrs = np.unique(days[YEAR])
    yr_nums = np.arange(yrs.size)
    mask_prcp = np.zeros(days[DATE].size,dtype=np.bool_) 
    
    for x in yr_nums:
        
        yr1_mask = days[YEAR]==yrs[x]
        
        prcp_yr1=prcp[yr1_mask]
        
        #need at least 3 nonzero values in the year
        if prcp_yr1[np.logical_and(np.isfinite(prcp_yr1),prcp_yr1>0)].size < 3:
            continue
    
        if not (x==np.max(yr_nums)):
            
            sub_yr_nums = np.arange(x+1,np.max(yr_nums)+1)
            
            for i in sub_yr_nums:
                
                yr2_mask = days[YEAR]==yrs[i]
                
                prcp_yr2=prcp[yr2_mask]

                #need at least 3 nonzero values in the year
                if prcp_yr2[np.logical_and(np.isfinite(prcp_yr2),prcp_yr2>0)].size < 3:
                    continue
                
                if is_dup_series(prcp_yr1, prcp_yr2):
                    yr_mask = np.logical_or(yr1_mask,yr2_mask)
                    mask_prcp = np.logical_or(mask_prcp,yr_mask)
    
    return update_obs_flags(prcp,flags_prcp,mask_prcp,QA_DUP_YEAR)

def qa_dup_month(prcp,days,flags_prcp):
    '''
    Check for duplicate values for same calendar month in different years
    '''
    
    yrs = np.unique(days[YEAR])
    yr_nums = np.arange(yrs.size)
    mask_prcp = np.zeros(days[DATE].size,dtype=np.bool_)
    
    mths = np.unique(days[MONTH])
    
    for x in yr_nums:
        
        yr1_mask = days[YEAR]==yrs[x]
        
        prcp_yr1=prcp[yr1_mask]
        
        mths_yr1=days[MONTH][yr1_mask]
        
        if not (x==np.max(yr_nums)):
            
            sub_yr_nums = np.arange(x+1,np.max(yr_nums)+1)
            
            for i in sub_yr_nums:
                
                yr2_mask = days[YEAR]==yrs[i]
                
                prcp_yr2=prcp[yr2_mask]
                
                mths_yr2=days[MONTH][yr2_mask]
                
                for month in mths:
                    
                    mask_mth_yr1 = mths_yr1==month
                    mask_mth_yr2 = mths_yr2==month
                    
                    prcp_yr1_mth = prcp_yr1[mask_mth_yr1]
                    prcp_yr2_mth = prcp_yr2[mask_mth_yr2]
                    
                    if prcp_yr1_mth[np.logical_and(np.isfinite(prcp_yr1_mth),prcp_yr1_mth>0)].size >= 3 and prcp_yr2_mth[np.logical_and(np.isfinite(prcp_yr2_mth),prcp_yr2_mth>0)].size >= 3 and is_dup_series(prcp_yr1_mth, prcp_yr2_mth):
                        yr_month_mask = np.logical_and(np.logical_or(yr1_mask,yr2_mask),days[MONTH]==month)
                        mask_prcp = np.logical_or(mask_prcp,yr_month_mask)
    
    
    return update_obs_flags(prcp,flags_prcp,mask_prcp,QA_DUP_MONTH)

def qa_imposs_value(prcp,days,flags_prcp):
    '''
    Check for values that are outside the bounds of world records or invalid (i.e.--<0)
    '''
    mask_prcp = np.logical_or(prcp<PRCP_MIN_VALUE,prcp>PRCP_MAX_VALUE)
    
    return update_obs_flags(prcp,flags_prcp,mask_prcp,QA_IMPOSS_VALUE)

def qa_streak(prcp,days,flags_prcp):
    '''
    Identify 20 or more consecutive prcp values
    '''    
    
    date_objs = days[DATE]
    date_nums = np.arange(date_objs.size)
    mask_prcp = np.zeros(date_objs.size,dtype=np.bool_)
    
    streak_indices = []
    
    for x in date_nums:
        
        if prcp[x] == 0 or np.isnan(prcp[x]):
            continue
        elif x == 0 or len(streak_indices) == 0:
            streak_indices.append(x)
        elif prcp[x] == prcp[streak_indices[-1]]:
            streak_indices.append(x)
        elif len(streak_indices) >= 20:
            mask_prcp[streak_indices] = True
            streak_indices = []
            streak_indices.append(x)
        else:
            streak_indices = []
            streak_indices.append(x)

    return update_obs_flags(prcp,flags_prcp,mask_prcp,QA_STREAK)

def qa_frequent(prcp,days,flags_prcp):
    '''
    Checks for frequent occurrences of the same value that might not necessarily be consecutive
    '''

    percentiles_leap = build_percentiles(prcp, days, DATES_366)

    date_objs = days[DATE]
    mask_prcp = np.zeros(date_objs.size,dtype=np.bool_)
    
    indices_consec = np.nonzero(np.logical_and(not_nan(prcp), prcp > 0))[0]
    prcp_consec = prcp[indices_consec]

    detected_values = []  # 存储被检测到的值及其对应的百分位数
    
    for x in np.arange(prcp_consec.size):

        vals_rng = prcp_consec[x:x+10]
        indices_rng = indices_consec[x:x+10]
        yr_days_rng = days[YDAY][indices_rng] - 1
        pctiles_rng = percentiles_leap[yr_days_rng,:]
        
        uniq_vals = np.unique(vals_rng)
        for val in uniq_vals:
            
            mask_val = vals_rng == val
            if vals_rng[mask_val].size >= 9 and pctiles_rng[mask_val,0][np.isfinite(pctiles_rng[mask_val,0])].size == pctiles_rng[mask_val,0].size and pctiles_rng[mask_val,0][val >= pctiles_rng[mask_val,0]].size == pctiles_rng[mask_val,0].size:
                mask_prcp[indices_rng[mask_val]] = True
            elif vals_rng[mask_val].size >= 8 and pctiles_rng[mask_val,1][np.isfinite(pctiles_rng[mask_val,1])].size == pctiles_rng[mask_val,1].size and pctiles_rng[mask_val,1][val >= pctiles_rng[mask_val,1]].size == pctiles_rng[mask_val,1].size:
                mask_prcp[indices_rng[mask_val]] = True
            elif vals_rng[mask_val].size >= 7 and pctiles_rng[mask_val,2][np.isfinite(pctiles_rng[mask_val,2])].size == pctiles_rng[mask_val,2].size and pctiles_rng[mask_val,2][val >= pctiles_rng[mask_val,2]].size == pctiles_rng[mask_val,2].size:
                mask_prcp[indices_rng[mask_val]] = True
            elif vals_rng[mask_val].size >= 5 and pctiles_rng[mask_val,3][np.isfinite(pctiles_rng[mask_val,3])].size == pctiles_rng[mask_val,3].size and pctiles_rng[mask_val,3][val >= pctiles_rng[mask_val,3]].size == pctiles_rng[mask_val,3].size:
                mask_prcp[indices_rng[mask_val]] = True
    
    return update_obs_flags(prcp, flags_prcp, mask_prcp, QA_FREQUENT)

def qa_gap(prcp,days,flags_prcp):
    '''
    Examines frequency distributions of prcp for calendar months and flags values in
    a distribution's tail that are unrealistically separated from the rest of the values
    '''

    mask_prcp = np.zeros(days[DATE].size,dtype=np.bool_)

    mths = days[MONTH]
    uniq_mths = np.unique(mths)
    
    for mth in uniq_mths:
        
        mth_mask = np.logical_and(np.logical_and(mths==mth,not_nan(prcp)),prcp>0)     #每个月份中排除nan值并且降水大于0
        
        prcp_mth = prcp[mth_mask]
        if prcp_mth.size == 0:
            continue
        prcp_mth = np.sort(prcp_mth)
        
        gap_mask = np.ediff1d(prcp_mth,to_begin=[0]) >= GAP_THRES   #np.ediff1d计算相邻元素的差值
    
        if prcp_mth[gap_mask].size > 0:
            gap_val = prcp_mth[gap_mask][0]
            mask_prcp[np.logical_and(mth_mask,prcp>=gap_val)] = True
    
    return update_obs_flags(prcp,flags_prcp,mask_prcp,QA_GAP)   

def qa_yr_clim_outlier(stn,stn_da,prcp,days,flags_prcp):
    
    mask_prcp = np.zeros(days[DATE].size,dtype=np.bool_)
    
    yrs = np.unique(days[YEAR])
    prcp_yrs = []
    chk_yrs = []
    for yr in yrs:
        
        mask_yr = np.logical_and(days[YEAR]==yr,np.isfinite(prcp))
    
        if prcp[mask_yr].size >= MIN_YR_DAYS_PRCP_OBS:
            prcp_yrs.append(np.sum(prcp[mask_yr]))
            chk_yrs.append(yr)
    
    prcp_yrs = np.array(prcp_yrs)
    chk_yrs = np.array(chk_yrs)
    if prcp_yrs.size >= MIN_NUM_YRS_PRCP:
        
        ngh_mask,dists = stns_in_radius_mask(stn,stn_da)
        ngh_ids = stn_da.stns[STN_ID][ngh_mask]
        ngh_ids = ngh_ids[np.logical_not(ngh_ids==stn[STN_ID])]
        dists = dists[np.logical_not(ngh_ids==stn[STN_ID])]
        ngh_obs = stn_da.load_all_stn_obs(ngh_ids)
        s_indices = np.argsort(dists)
        
        dists = dists[s_indices]
        ngh_ids = ngh_ids[s_indices]
        ngh_obs_prcp = ngh_obs[PRCP][:,s_indices]

        obs_ngh_ann_prcp = []
        for x in np.arange(ngh_ids.size):
            
            ngh_prcp = ngh_obs_prcp[:,x]
            ngh_ann_prcp = np.ones(len(prcp_yrs))*np.nan
            
            for i in np.arange(len(chk_yrs)):
                
                mask_stn_yr = np.logical_and(days[YEAR]==chk_yrs[i],np.isfinite(ngh_prcp))
                
                if ngh_prcp[mask_stn_yr].size >= MIN_YR_DAYS_PRCP_OBS:
                    ngh_ann_prcp[i] = np.sum(ngh_prcp[mask_stn_yr])
            
            if ngh_ann_prcp[np.isfinite(ngh_ann_prcp)].size >= MIN_NUM_YRS_PRCP*(2.0/3.0):
                obs_ngh_ann_prcp.append(ngh_ann_prcp)
        
        if len(obs_ngh_ann_prcp) >= MIN_NGHS:
            
            ioas = []
            lin_mods = []
            for ngh_ann_prcp in obs_ngh_ann_prcp:
                
                mask_overlap = np.isfinite(ngh_ann_prcp)
                ioas.append(calc_ioa(prcp_yrs[mask_overlap],ngh_ann_prcp[mask_overlap]))
                lin_mods.append(build_lin_model(ngh_ann_prcp[mask_overlap],prcp_yrs[mask_overlap]))
        
            ann_prcp_predicts = np.ones(prcp_yrs.size)*np.nan
            
            ioas = np.array(ioas)
            obs_ngh_ann_prcp = object_array(obs_ngh_ann_prcp)
            lin_mods = object_array(lin_mods)
            
            s_indices = np.argsort(ioas)
            s_indices = s_indices[::-1]
            obs_ngh_ann_prcp = obs_ngh_ann_prcp[s_indices]
            ioas = ioas[s_indices]
            lin_mods = lin_mods[s_indices]
            
            for x in np.arange(prcp_yrs.size):
                
                wght_ests = []
                wghts = []
                n = 0
                for i in np.arange(len(obs_ngh_ann_prcp)):
                    
                    ngh_ann_prcp = obs_ngh_ann_prcp[i]
                    
                    if np.isfinite(ngh_ann_prcp[x]):
                        
                        lin_mod = lin_mods[i]
                        a = lin_mod[0] #slope
                        b = lin_mod[1] #intercept
                        d = ioas[i] #weight

                        wght_ests.append((b+(a*ngh_ann_prcp[x]))*d)
                        wghts.append(d)
                        n+=1
                    if n == MAX_NGHS:
                        break
                
                if n >= MIN_NGHS:
                    
                    wght_ests = np.array(wght_ests)
                    wghts = np.array(wghts)
                    ann_prcp_predicts[x] = np.sum(wght_ests)/np.sum(wghts)
            
            prcp_yrs[prcp_yrs==0] = 1.0
            resid = np.abs(prcp_yrs-ann_prcp_predicts)/prcp_yrs*100
            mask_finite_resid = np.isfinite(resid)
            resid_std = np.abs((resid - np.mean(resid[mask_finite_resid]))/np.std(resid[mask_finite_resid]))
            yrs_flagged = chk_yrs[np.logical_and(resid>=NGH_RESID_CUTOFF,resid_std>=NGH_RESID_STD_CUTOFF)]
            if yrs_flagged.size > 0:
                mask_prcp[np.in1d(days[YEAR], yrs_flagged)] = True
                
    return update_obs_flags(prcp,flags_prcp,mask_prcp,QA_YR_CLIM_OUTLIER)       

def qa_clim_outlier(prcp,tavg,days,flags_prcp):
    
    '''
    Checks for prcp outliers based on relation to 29-day climate norm 95th percentile
    Must have 20 nonzero values in the 29-day period of record for the check to run
    '''
    
    pctiles = build_percentiles(prcp, days, DATES_366)
    
    date_objs = days[DATE]
    ydays = days[YDAY]
    mask_prcp = np.zeros(date_objs.size,dtype=np.bool_)
    
    indices = np.nonzero(np.logical_and(not_nan(prcp),prcp>0))[0]
    prcp_nonzero = prcp[indices]
    
    for x in np.arange(prcp_nonzero.size):
        
        day_num = ydays[indices[x]] - 1
        
        #check that a val and norm exists
        if not_nan(pctiles[day_num,4]):
            
            if not_nan(tavg[indices[x]]) and tavg[indices[x]] < 0.0:     #根据气温设置阈值
                m = 5.0
            else:
                m = 9.0
            
            mask_prcp[indices[x]] =  prcp_nonzero[x] >= (m*pctiles[day_num,4])
    
    return update_obs_flags(prcp,flags_prcp,mask_prcp,QA_CLIM_OUTLIER)

#TODO
def qa_spatial_corrob(stn, stn_da, prcp, days, flags_prcp, ngh_data=None):
    '''
    Check for prcp observations that are not corroborated by any neighboring observations
    '''

    date_objs = days[DATE]
    mask_prcp = np.zeros(date_objs.size, dtype=np.bool_)

    if ngh_data is None:

        ngh_mask, dists = stns_in_radius_mask(stn, stn_da)
        ngh_ids = stn_da.stns[STN_ID][ngh_mask]
        dists = dists[np.logical_not(ngh_ids == stn[STN_ID])]
        ngh_ids = ngh_ids[np.logical_not(ngh_ids == stn[STN_ID])]
        ngh_obs = None
    else:
        ngh_ids, dists, ngh_obs = ngh_data
    #获取距离唯一值，并得到唯一值出现时的索引
    unique_dists, indices = np.unique(dists, return_index=True)   #return_index可以返回排序前第一次出现的旧索引
    ngh_ids = ngh_ids[indices]

    unique_ngh_ids, unique_indices = np.unique(ngh_ids, return_index=True)
    ngh_ids = ngh_ids[np.sort(unique_indices)]

    if ngh_ids.size >= MIN_NGHS:

        if ngh_obs is None:
            ngh_obs = pd.DataFrame()
            #按站点顺序获取值
            for ngh in ngh_ids:
                obs_data = stn_da.load_all_stn_obs(ngh)
                obs_data = obs_data[PRCP]
                # 创建一个临时的 DataFrame，并将数据作为该站点的列
                temp_df = pd.DataFrame({ngh: obs_data})
                # 按列合并所有数据
                ngh_obs = pd.concat([ngh_obs, temp_df], axis=1)

        ngh_obs_prcp = ngh_obs.values

        pctiles_masks = get_pctiles_md_masks(days, DATES_366)

        ngh_pors = []
        for x in np.arange(ngh_obs_prcp.shape[1]):
            ngh_pors.append(build_pors(ngh_obs_prcp[:, x], pctiles_masks))
        ngh_pors = object_array(ngh_pors)
        stn_pors = build_pors(prcp, pctiles_masks)

        for x in np.arange(date_objs.size):
            # Don't perform check on first/last day of time series
            if x == 0 or x == date_objs.size - 1 or np.isnan(prcp[x]):
                continue

            mask_prcp[x] = get_spatial_corrob_flag(prcp, ngh_obs_prcp, stn_pors, ngh_pors, x, days)

    #    else:
    #        #Station had no nghs in range
    #        print "".join([stn[STN_ID],": could not perform prcp qa_spatial_corrob--no nghs in range."])

    return update_obs_flags(prcp, flags_prcp, mask_prcp, QA_SPATIAL_CORROB)

def qa_spatial_corrob1(stn, stn_da, prcp, days, flags_prcp, ngh_data=None):
    '''
    Check for prcp observations that are not corroborated by any neighboring observations
    '''

    date_objs = days[DATE]
    mask_prcp = np.zeros(date_objs.size, dtype=np.bool_)

    if ngh_data is None:

        ngh_mask, dists = stns_in_radius_mask(stn, stn_da)
        ngh_ids = stn_da.stns[STN_ID][ngh_mask]
        dists = dists[np.logical_not(ngh_ids == stn[STN_ID])]
        ngh_ids = ngh_ids[np.logical_not(ngh_ids == stn[STN_ID])]
        ngh_obs = None
    else:
        ngh_ids, dists, ngh_obs = ngh_data

    if ngh_ids.size >= MIN_NGHS:

        if ngh_obs is None:
            ngh_obs_list = []
            for n in np.unique(ngh_ids):
                obs = stn_da.load_all_stn_obs(n)
                ngh_obs_list.append(obs)
            ngh_obs = np.concatenate(ngh_obs_list, axis=0)

            # ngh_obs = stn_da.load_all_stn_obs(ngh_ids)

        s_indices = np.argsort(dists)

        dists = dists[s_indices]
        ngh_ids = ngh_ids[s_indices]
        ngh_obs_prcp = ngh_obs[PRCP].reshape(1,-1)[:, s_indices]

        pctiles_masks = get_pctiles_md_masks(days, DATES_366)
        ngh_pors = []
        for x in np.arange(ngh_obs_prcp.shape[1]):
            ngh_pors.append(build_pors(ngh_obs_prcp[:, x], pctiles_masks))
        ngh_pors = object_array(ngh_pors)
        stn_pors = build_pors(prcp, pctiles_masks)

        for x in np.arange(date_objs.size):

            # Don't perform check on first/last day of time series
            if x == 0 or x == date_objs.size - 1 or np.isnan(prcp[x]):
                continue

            mask_prcp[x] = get_spatial_corrob_flag(prcp, ngh_obs_prcp, stn_pors, ngh_pors, x, days)

    #    else:
    #        #Station had no nghs in range
    #        print "".join([stn[STN_ID],": could not perform prcp qa_spatial_corrob--no nghs in range."])

    return update_obs_flags(prcp, flags_prcp, mask_prcp, QA_SPATIAL_CORROB)

def calc_ioa(x,y):
    y_mean = np.mean(y)
    ioa = 1.0 - (np.sum(np.abs(y-x))/np.sum(np.abs(x-y_mean)+np.abs(y-y_mean)))
    return ioa

def build_lin_model(x,y):
    slope, intercept, r_value, p_value, std_err = stats.linregress(x,y)
    return slope, intercept, r_value, p_value, std_err 

def build_pors(prcp,pctiles_masks):
    
    pors = []
    for x in np.arange(pctiles_masks.shape[0]):
        
        pors.append(prcp[np.logical_and(np.logical_and(not_nan(prcp),prcp>0.0),pctiles_masks[x,:])])
    return pors

def get_spatial_corrob_flag(prcp,ngh_obs_prcp,stn_pors,ngh_pors,obs_num,days):
    """
    进行空间确证判断：当前站点日期降水数据和邻近站点3天的历史降水数据对比，根据绝对差值和阈值大小进行判断，
    并根据当前站点日期降水数据在历史降水数据的百分位数和邻近站点3天在历史数据中的百分位数进行阈值的动态调整
    """

    day_num_prev = days[YDAY][obs_num-1] - 1
    day_num_cur = days[YDAY][obs_num] - 1
    day_num_nxt = days[YDAY][obs_num+1] - 1

    # 判断邻近站点前后天和当前天的降水是否为有效值
    mask_finite_prev = np.isfinite(ngh_obs_prcp[obs_num-1,:])
    mask_finite_cur = np.isfinite(ngh_obs_prcp[obs_num,:])
    mask_finite_nxt = np.isfinite(ngh_obs_prcp[obs_num+1,:])
    
    if (np.nonzero(mask_finite_prev)[0].size >= MIN_NGHS and np.nonzero(mask_finite_cur)[0].size >= MIN_NGHS
            and np.nonzero(mask_finite_nxt)[0].size >= MIN_NGHS):    #判断邻近站点的有效数据点是否有三个

        # 获取这三天的有效数据（邻近站距离远近的排序也在这里体现，因为下面只获取前七个站点的数据）
        ngh_obs_prev = ngh_obs_prcp[obs_num-1,mask_finite_prev]
        ngh_obs_cur = ngh_obs_prcp[obs_num,mask_finite_cur]
        ngh_obs_nxt = ngh_obs_prcp[obs_num+1,mask_finite_nxt]
        ngh_obs_all = np.concatenate([ngh_obs_prev[0:MAX_NGHS],ngh_obs_cur[0:MAX_NGHS],ngh_obs_nxt[0:MAX_NGHS]])

        # 比较当前站点的降水是否在邻近站点日期的数据的范围内，如果不在计算绝对差值，比较阈值和绝对差值的大小，返回判断结果，否则没有异常
        if prcp[obs_num] > np.max(ngh_obs_all):
            abs_dif = abs(prcp[obs_num]-np.max(ngh_obs_all))
        elif prcp[obs_num] < np.min(ngh_obs_all):
            abs_dif = abs(prcp[obs_num]-np.min(ngh_obs_all))
        else: 
            abs_dif = 0.0
            return False

        # 计算当前站点降水数据在历史数据中的百分位数
        if stn_pors[day_num_cur].size > MIN_PERCENTILE_VALUES:
            
            prcp_pctile = stats.percentileofscore(stn_pors[day_num_cur],prcp[obs_num])

            ngh_pors_prev = ngh_pors[mask_finite_prev]
            ngh_pors_cur = ngh_pors[mask_finite_cur]
            ngh_pors_nxt = ngh_pors[mask_finite_nxt]

            # 计算邻近站点数据在降水历史数据中的百分位数(前一天、当前天、后一天)
            ngh_pctiles_prev = []
            for ngh in np.arange(ngh_obs_prev.size):
                
                ngh_prcp = ngh_obs_prev[ngh]
                
                if ngh_pors_prev[ngh][day_num_prev].size > MIN_PERCENTILE_VALUES:
                    
                    ngh_pctiles_prev.append(stats.percentileofscore(ngh_pors_prev[ngh][day_num_prev],ngh_prcp))

                if len(ngh_pctiles_prev) == MAX_NGHS:
                    break
                
            ngh_pctiles_prev = np.array(ngh_pctiles_prev)
            ##############################
            ngh_pctiles_cur = []
            for ngh in np.arange(ngh_obs_cur.size):
                
                ngh_prcp = ngh_obs_cur[ngh]

                if ngh_pors_cur[ngh][day_num_cur].size > MIN_PERCENTILE_VALUES:
                    
                    ngh_pctiles_cur.append(stats.percentileofscore(ngh_pors_cur[ngh][day_num_cur],ngh_prcp))

                if len(ngh_pctiles_cur) == MAX_NGHS:
                    break
                
            ngh_pctiles_cur = np.array(ngh_pctiles_cur)
            ##############################
            ngh_pctiles_nxt = []
            for ngh in np.arange(ngh_obs_nxt.size):
                
                ngh_prcp = ngh_obs_nxt[ngh]
                
                if ngh_pors_nxt[ngh][day_num_nxt].size > MIN_PERCENTILE_VALUES:
                    
                    ngh_pctiles_nxt.append(stats.percentileofscore(ngh_pors_nxt[ngh][day_num_nxt],ngh_prcp))

                if len(ngh_pctiles_nxt) == MAX_NGHS:
                    break
                     
            ngh_pctiles_nxt = np.array(ngh_pctiles_nxt)

            # 检查当前站点和邻近站点的百分位数的差异并进行阈值计算
            if ngh_pctiles_prev.size >= MIN_NGHS and ngh_pctiles_cur.size >= MIN_NGHS and ngh_pctiles_nxt.size >= MIN_NGHS:
                
                ngh_pctiles_all = np.concatenate([ngh_obs_prev,ngh_obs_cur,ngh_obs_nxt])
                
                if prcp_pctile > np.max(ngh_pctiles_all):
                    pctile_dif = abs(prcp_pctile-np.max(ngh_pctiles_all))
                elif prcp_pctile < np.min(ngh_pctiles_all):
                    pctile_dif = abs(prcp_pctile-np.min(ngh_pctiles_all))
                else: 
                    pctile_dif = 0.0
                
                if pctile_dif == 0:
                    thres = MAX_SPATIAL_COLLAB_THRES
                else:
                    thres = ((-45.72*math.log(pctile_dif)) + MAX_SPATIAL_COLLAB_THRES_MM)/10.0
            else:
                thres = MAX_SPATIAL_COLLAB_THRES
        else:
            thres = MAX_SPATIAL_COLLAB_THRES

        return abs_dif > thres
    else:
        return False

def stns_in_radius_mask(stn,stn_da,radius=NGH_RADIUS):

    dists = utlg.grt_circle_dist(stn[LON], stn[LAT], stn_da.stns[LON], stn_da.stns[LAT])
    if len(str(stn_da.stns[STN_ID])) == 11:
        mask = dists <= radius
    else:
        mask = np.logical_and(dists <= radius,np.char.startswith(stn_da.stns[STN_ID],"5"))  # 5是非自动站点的值

    return mask,dists[mask]

def build_percentiles(vals,days,yr_days):
    
    mth_days = utld.get_md_array(days[DATE])
    
    # Build 29-day percentiles for every day in yr_days
    day_nums = np.arange(yr_days.size)
    # Columns: 30th,50th,70th,90th,95th
    percentiles = np.ones([yr_days.size,5])*np.nan
    
    for x in day_nums:
        date = yr_days[x]
        srt_date = date - utld.TWO_WEEKS
        end_date = date + utld.TWO_WEEKS
        date_range = utld.get_date_array(srt_date, end_date)
        mth_days_range = utld.get_md_array(date_range)
        
        date_mask = np.in1d(mth_days,mth_days_range)     #检查 mth_days 中的每个元素是否存在于 mth_days_range 中，并返回一个布尔数组
        vals_rng = vals[np.logical_and(np.logical_and(not_nan(vals),vals>0),date_mask)]
        
        if vals_rng.size >= MIN_PERCENTILE_VALUES:
            percentiles[x,:] = [np.percentile(vals_rng,30),np.percentile(vals_rng,50),np.percentile(vals_rng,70),np.percentile(vals_rng,90),np.percentile(vals_rng,95)]
    
    return percentiles

def get_pctiles_md_masks(days,yr_days):
    
    mth_days = utld.get_md_array(days[DATE])
    
    day_nums = np.arange(yr_days.size)
    
    pctile_masks = np.zeros((yr_days.size,mth_days.size),dtype=np.bool_)   ############np.bool_
    
    for x in day_nums:
        
        mth_day = yr_days[x]
        srt_mth_day = mth_day - utld.TWO_WEEKS
        end_mth_day = mth_day + utld.TWO_WEEKS
        date_range = utld.get_date_array(srt_mth_day, end_mth_day)
        mth_days_range = utld.get_md_array(date_range)
        
        pctile_masks[x,:] = np.in1d(mth_days,mth_days_range)
    
    return pctile_masks

def is_dup_series(vals_yr1,vals_yr2):
    
    if vals_yr1[not_nan(vals_yr1)].size > 0 and vals_yr2[not_nan(vals_yr2)].size > 0:
        
        #Compare up to last day of the shortest series
        last_day = np.min([vals_yr1.size,vals_yr2.size])  
        dup=np.nonzero(vals_yr1[0:last_day] == vals_yr2[0:last_day])[0].size == vals_yr2[0:last_day].size
    else:
        dup=False
    
    return dup

def not_nan(vals):
    return np.logical_not(np.isnan(vals))

def apply_2d_mask(a,row_mask,col_mask):
    b = a[row_mask,:]
    b = b[:,col_mask]
    return b

def object_array(x):
    array = np.empty(len(x), dtype=object)  #dtype=np.object
    for i in range(len(x)):
        array[i] = x[i]
    return array

def update_obs_flags(prcp,flags_prcp,mask_prcp,flag):
    
    prcp[mask_prcp] = np.nan          #没通过判断条件的值被赋值为nan
    flags_prcp[np.logical_and(flags_prcp == QA_OK,mask_prcp)] = flag

    return prcp,flags_prcp

def mad(a):
    '''
    Calculates median absolute deviations 
    '''
    return np.median(np.abs(a-np.median(a)))

def biweight_mean_std(X):
    '''
    Calculates more robust mean/std for climate data
    Used by Durre et al. 2010 referencing Lanzante 1996
    '''
    
    #mean
    c = 7.5
    M = np.median(X)
    MAD = mad(X)
    
    if MAD == 0:
        #return normal mean, std. biweight cannot be calculated
        return np.mean(X),np.std(X,ddof=1)
    
    u = (X - M)/(c*MAD)
    u[np.abs(u)>=1.0]=1.0
    Xbi = M + (np.sum((X-M)*(1.0-u**2)**2)/np.sum((1-u**2)**2))
    
    #std
    n = X.size
    Sbi = ((n*np.sum(((X-M)**2)*(1-u**2)**4))**0.5)/np.abs(np.sum((1-u**2)*(1-(5*u**2))))
    
    #return np.mean(X),np.std(X)
    
    return Xbi,Sbi 

if __name__ == '__main__':
    pass



